from django.shortcuts import render
from django.http import HttpResponse
from django.contrib import auth

# Create your views here.

def me(request):
    user = auth.get_user(request)
    if not user.is_authenticated:
        return HttpResponse('not logged in :O')
    return do_profile(request, user)

def profile(request, id):
    return do_profile(request, auth.models.User.objects.get(id=id))

def profile_username(request, username):
    return do_profile(request, auth.models.User.objects.get(username=username))

def all_profiles(request):
    user_session = auth.get_user(request)
    return render(request, 'all_profiles.html', context =
            {
                'loggedin': user_session.username if user_session.is_authenticated else None,
                'users': auth.models.User.objects.all(),
                })

def do_profile(request, user):
    user_session = auth.get_user(request)
    loggedin = user_session == user
    return render(request, 'profile.html', context =
            {
                'loggedin': user_session.username if user_session.is_authenticated else None,
                'edit': loggedin,
                'avatar': user.profile.picture.url if user.profile.picture else None,
                'username': user.username,
                'name_first': user.first_name,
                'name_last': user.last_name,
                'bio': user.profile.bio,
                'website': user.profile.website,
                'dm_form': ComposeMessage(),
                })

from django.http import HttpResponseRedirect
from django.urls import reverse
from .forms import *

def edit(request):
    user = auth.get_user(request)
    if not user.is_authenticated:
        return HttpResponse('not logged in :O')
    form = EditProfileForm(initial = {
        'name_first': user.first_name,
        'name_last': user.last_name,
        'avatar': user.profile.picture,
        'bio': user.profile.bio,
        'url': user.profile.website,
        'email': user.email,
        })
    if request.method == 'POST':
        form = EditProfileForm(request.POST, request.FILES)
        if form.is_valid():
            cleaned = form.cleaned_data
            password = cleaned['password']
            if password:
                password_again = cleaned['password_again']
                if password == password_again:
                    user.set_password(password)
                else:
                    return render(request, 'profile_edit.html', {
                        'loggedin': user.username,
                        'form': form,
                        'username': user.username,
                        'error': 'Passwords don\'t match.',
                        })
            user.first_name = cleaned['name_first']
            user.last_name = cleaned['name_last']
            user.email = cleaned['email']
            user.profile.bio = cleaned['bio']
            user.profile.website = cleaned['url']
            if cleaned['avatar'] == False:
                user.profile.picture = None
            elif request.FILES:
                user.profile.picture = request.FILES['avatar']
            user.profile.save()
            user.save()
            auth.login(request, user) # changing passwords logs out by default
            return HttpResponseRedirect(reverse('me'))
    else:
        return render(request, 'profile_edit.html', {
            'loggedin': user.username,
            'form': form,
            'username': user.username,
            })

def login(request):
    error = False
    if request.method == 'POST':
        form = FormLogin(request.POST)
        if form.is_valid():
            cleaned = form.cleaned_data
            username = cleaned['username']
            password = cleaned['password']
            user = auth.authenticate(request, username=username, password=password)
            if user:
                auth.login(request, user)
                return HttpResponseRedirect(reverse('me'))
            error = 'Invalid username and/or password.'
    return render(request, 'account.html', {'form': FormLogin(), 'error': error})


def logout(request):
    auth.logout(request)
    return HttpResponseRedirect(reverse('all'))

from .models import Profile

def register(request):
    error = False
    if request.method == 'POST':
        form = FormRegister(request.POST)
        if form.is_valid():
            cleaned = form.cleaned_data
            name_first = cleaned['name_first']
            name_last = cleaned['name_last']
            username = cleaned['username']
            if username == 'me':
                error = 'Username cannot be \'me\'.'
            else:
                password = cleaned['password']
                password_again = cleaned['password_again']
                email = cleaned['email']
                if password == password_again:
                    user = auth.models.User.objects.create_user(username, email, password)
                    user.first_name = name_first
                    user.last_name = name_last
                    user.is_staff = False
                    user.is_superuser = False
                    user.save()
                    Profile.objects.create(
                        user = user,
                        picture = None,
                        bio = '',
                        website = ''
                        ).save()
                    auth.login(request, user)
                    return HttpResponseRedirect(reverse('me'))
                error = 'Invalid passwords.'
    return render(request, 'account.html', {'form': FormRegister(), 'error': error})

def home(request):
    user = auth.get_user(request)
    return render(request, 'home.html', {'loggedin': user.username if user.is_authenticated else None})


