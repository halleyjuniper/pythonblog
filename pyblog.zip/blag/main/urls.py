from django.views.generic import RedirectView
from django.urls import path, reverse
from . import views

urlpatterns = [
    path('profile/@me', views.me, name='me'),
    path('profile/<int:id>', views.profile, name='profile'),
    path('profile/@me/edit', views.edit, name='profile_edit'),
    path('profile/@<username>', views.profile_username),
    path('profile/all', views.all_profiles, name='all'),
    path('account/login', views.login, name='login'),
    path('account/logout', views.logout, name='logout'),
    path('account/register', views.register, name='register'),
    path('home', views.home, name='home'),
    #path('', RedirectView.as_view(url=reverse('all'), permanent = True)),
]

