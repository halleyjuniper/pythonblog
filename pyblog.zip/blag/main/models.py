from django.db import models
from django.contrib import auth

# Create your models here.

class Profile(models.Model):
    user = models.OneToOneField(
            auth.models.User,
            on_delete=models.CASCADE,
            related_name='profile',
            )
    picture = models.ImageField(
            null=True,
            blank=True,
            upload_to='uploads/')
    bio = models.TextField()
    website = models.URLField(blank=True)

    def __str__(self):
        return self.user.username
        #return str(self.__dict__)

class Message(models.Model):
        author = models.ForeignKey(
                auth.models.User,
                on_delete=models.CASCADE,
                related_name='author',
        )
        recipient =  models.ForeignKey(
                auth.models.User,
                on_delete=models.CASCADE,
                related_name='recipient',
        )
        content = models.TextField()
        when = models.DateField()


