from django import forms

class EditProfileForm(forms.Form):
    name_first = forms.CharField()
    name_last = forms.CharField()
    avatar = forms.ImageField(required=False)
    bio = forms.CharField(required=False, widget = forms.Textarea())
    url = forms.URLField(required=False)
    email = forms.EmailField()
    password = forms.CharField(required=False, widget = forms.PasswordInput())
    password_again = forms.CharField(required=False, widget = forms.PasswordInput())

class FormLogin(forms.Form):
    username = forms.CharField()
    password = forms.CharField(widget = forms.PasswordInput())

class FormRegister(forms.Form):
    name_first = forms.CharField()
    name_last = forms.CharField()
    username = forms.CharField()
    password = forms.CharField(widget = forms.PasswordInput())
    password_again = forms.CharField(widget = forms.PasswordInput())
    email = forms.EmailField()

class ComposeMessage(forms.Form):
    content = forms.CharField(widget = forms.TextInput())


